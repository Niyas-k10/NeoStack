const faq = [
  {
    id: 1,
    question: "How long does it take to build a website?",
    answer:
      "A standard business website usually takes between 7–14 days depending on the features and project requirements.",
  },
  {
    id: 2,
    question: "Do you create responsive websites?",
    answer:
      "Yes. Every website we build is fully responsive and optimized for desktop, tablet and mobile devices.",
  },
  {
    id: 3,
    question: "Can you redesign my existing website?",
    answer:
      "Absolutely. We can modernize your existing website with a fresh UI, improved performance and better user experience.",
  },
  {
    id: 4,
    question: "Do you provide SEO optimization?",
    answer:
      "Yes. We follow modern SEO best practices including semantic HTML, metadata, performance optimization and clean code.",
  },
  {
    id: 5,
    question: "What technologies do you use?",
    answer:
      "We primarily work with React, Tailwind CSS, JavaScript, Django, REST APIs, MySQL, GSAP and Three.js.",
  },
  {
    id: 6,
    question: "Do you provide support after project delivery?",
    answer:
      "Yes. We provide post-launch support, maintenance and future enhancements whenever required.",
  },
];

export default faq;