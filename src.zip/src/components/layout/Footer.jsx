import {
  FaInstagram,
  FaWhatsapp,
  FaLinkedin,
  FaGithub,
} from "react-icons/fa";

import { MdEmail } from "react-icons/md";

const quickLinks = [
  {
    title: "Home",
    href: "#hero",
  },
  {
    title: "Services",
    href: "#services",
  },
  {
    title: "Tech Stack",
    href: "#tech",
  },
  {
    title: "Portfolio",
    href: "#portfolio",
  },
  {
    title: "Process",
    href: "#process",
  },
  {
    title: "FAQ",
    href: "#faq",
  },
];

const services = [
  "Website Development",
  "Brand Identity",
  "Poster Design",
  "Digital Marketing",
  "ATS Resume",
];

const socials = [
  {
    icon: FaWhatsapp,
    href: "https://wa.me/91XXXXXXXXXX",
  },
  {
    icon: FaInstagram,
    href: "https://instagram.com/neostack.in",
  },
  {
    icon: FaLinkedin,
    href: "https://linkedin.com",
  },
  {
    icon: FaGithub,
    href: "https://github.com",
  },
];

function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-[#050505] text-white">

      {/* Glow */}

      <div className="absolute left-1/2 top-0 h-[350px] w-[350px] -translate-x-1/2 rounded-full bg-yellow-500/10 blur-[140px]" />

      <div className="relative mx-auto max-w-7xl px-6">

        {/* Top */}

        <div className="border-b border-white/10 py-20">

          <div className="grid gap-16 lg:grid-cols-4">

            {/* Brand */}

            <div>

              <h2 className="text-4xl font-bold">

                NeoStack

              </h2>

              <p className="mt-6 leading-8 text-gray-400">

                We craft premium digital
                experiences that help startups
                and businesses grow through
                modern design and technology.

              </p>

              <div className="mt-8 flex gap-4">

                {socials.map((item, index) => {
                  const Icon = item.icon;

                  return (
                    <a
                      key={index}
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-[#101010] text-lg transition-all duration-300 hover:-translate-y-1 hover:border-yellow-400 hover:bg-yellow-400 hover:text-black"
                    >

                      <Icon />

                    </a>
                  );
                })}

              </div>

            </div>

            {/* Quick Links */}

            <div>

              <h3 className="text-xl font-semibold">
                Quick Links
              </h3>

              <ul className="mt-8 space-y-4">

                {quickLinks.map((item) => (

                  <li key={item.title}>

                    <a
                      href={item.href}
                      className="text-gray-400 transition hover:text-yellow-400"
                    >
                      {item.title}
                    </a>

                  </li>

                ))}

              </ul>

            </div>

            {/* Services */}

            <div>

              <h3 className="text-xl font-semibold">
                Services
              </h3>

              <ul className="mt-8 space-y-4">

                {services.map((service) => (

                  <li
                    key={service}
                    className="text-gray-400"
                  >
                    {service}
                  </li>

                ))}

              </ul>

            </div>

            {/* Contact */}

            <div>

              <h3 className="text-xl font-semibold">
                Contact
              </h3>

              <div className="mt-8 space-y-5">

                <p className="text-gray-400">
                  Kerala, India
                </p>

                <p className="flex items-center gap-3 text-gray-400">

                  <MdEmail className="text-yellow-400" />

                  hello@neostack.in

                </p>

                <p className="text-gray-400">
                  +91 XXXXX XXXXX
                </p>

                <p className="text-yellow-400">
                  Build • Scale • Evolve
                </p>

              </div>

            </div>

          </div>

        </div>

        {/* Bottom */}

        <div className="flex flex-col items-center justify-between gap-5 py-8 text-center md:flex-row">

          <p className="text-gray-500">

            © 2026 NeoStack. All Rights Reserved.

          </p>

          <p className="text-gray-500">

            Designed & Developed by NeoStack

          </p>

        </div>

      </div>

    </footer>
  );
}

export default Footer;