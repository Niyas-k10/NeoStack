import HeroContent from "./HeroContent";
import HeroCanvas from "../../three/HeroCanvas";

function Hero() {
  return (
    <section
      id="hero"
      className="relative overflow-hidden bg-[#050505] pt-28 pb-24"
    >
      {/* Background Glow */}
      <div className="absolute left-1/2 top-32 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-yellow-500/10 blur-[180px]" />

      {/* Grid */}
      <div className="absolute inset-0 opacity-[0.04]">
        <div
          className="h-full w-full"
          style={{
            backgroundImage: `
              linear-gradient(rgba(255,255,255,.15) 1px, transparent 1px),
              linear-gradient(90deg, rgba(255,255,255,.15) 1px, transparent 1px)
            `,
            backgroundSize: "70px 70px",
          }}
        />
      </div>

      <div className="relative mx-auto flex max-w-7xl flex-col items-center px-6">

        <HeroContent />

        <div className="mt-10 w-full">
          <HeroCanvas />
        </div>

      </div>
    </section>
  );
}

export default Hero;