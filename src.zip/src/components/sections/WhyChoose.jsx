import SectionHeading from "../common/SectionHeading";

const features = [
  {
    title: "Modern UI / UX",
    description:
      "Beautiful, clean and premium interfaces designed to create a lasting first impression.",
  },
  {
    title: "High Performance",
    description:
      "Optimized code, fast loading speed and smooth user experience across all devices.",
  },
  {
    title: "SEO Optimized",
    description:
      "Built with modern SEO practices to improve visibility and help your business grow online.",
  },
  {
    title: "Scalable Solutions",
    description:
      "Future-ready websites that are easy to maintain and grow with your business.",
  },
];

function WhyChoose() {
  return (
    <section
      id="why"
      className="reveal bg-[#050505] py-32 text-white"
    >
      <div className="mx-auto max-w-7xl px-6">

        <SectionHeading
          subtitle="Why Choose NeoStack"
          title="Built For Businesses That Want To Stand Out"
          description="We don't just build websites. We create modern digital experiences that help businesses grow, build trust and leave a lasting impression."
        />

        <div className="mt-20 grid gap-8 lg:grid-cols-2">

          {/* Left */}

          <div className="relative overflow-hidden rounded-[36px] border border-white/10 bg-[#101010] p-12">

            <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-yellow-500/10 blur-[120px]" />

            <div className="relative">

              <p className="uppercase tracking-[6px] text-yellow-400">
                Why We Are Different
              </p>

              <h2 className="mt-6 text-4xl font-bold leading-tight lg:text-5xl">
                We Build Digital
                <br />
                Experiences,
                <br />
                Not Just Websites.
              </h2>

              <p className="mt-8 leading-8 text-gray-400">
                Every project is designed with strategy, performance,
                user experience and scalability in mind. Our goal is
                to create products that help businesses grow and
                establish a strong digital presence.
              </p>

              <div className="mt-12 grid grid-cols-2 gap-8">

                <div>
                  <h3 className="text-5xl font-bold text-yellow-400">
                    100%
                  </h3>

                  <p className="mt-3 text-gray-500">
                    Responsive Design
                  </p>
                </div>

                <div>
                  <h3 className="text-5xl font-bold text-yellow-400">
                    Fast
                  </h3>

                  <p className="mt-3 text-gray-500">
                    Performance
                  </p>
                </div>

              </div>

            </div>

          </div>

          {/* Right */}

          <div className="grid gap-6 sm:grid-cols-2">

            {features.map((feature) => (

              <div
                key={feature.title}
                className="group rounded-[28px] border border-white/10 bg-[#101010] p-8 transition-all duration-500 hover:-translate-y-2 hover:border-yellow-400 hover:shadow-[0_0_40px_rgba(245,183,0,0.08)]"
              >

                <div className="mb-6 h-1 w-14 rounded-full bg-yellow-400" />

                <h3 className="text-2xl font-bold">
                  {feature.title}
                </h3>

                <p className="mt-5 leading-8 text-gray-400">
                  {feature.description}
                </p>

              </div>

            ))}

          </div>

        </div>

      </div>
    </section>
  );
}

export default WhyChoose;