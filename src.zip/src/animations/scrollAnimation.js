import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

export function scrollAnimation() {
  gsap.to(".hero-content", {
    opacity: 0,
    y: -150,
    ease: "none",

    scrollTrigger: {
      trigger: "#hero",
      start: "top top",
      end: "70% top",
      scrub: true,
    },
  });

  gsap.to(".hero-scene", {
    scale: 0.75,
    y: -120,
    ease: "none",

    scrollTrigger: {
      trigger: "#hero",
      start: "top top",
      end: "bottom top",
      scrub: true,
    },
  });

  gsap.from(".services-section", {
    opacity: 0,
    y: 120,

    scrollTrigger: {
      trigger: "#services",
      start: "top 75%",
      end: "top 50%",
      scrub: 1,
    },
  });
}