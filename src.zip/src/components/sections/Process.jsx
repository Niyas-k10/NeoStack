import SectionHeading from "../common/SectionHeading";
import process from "../../data/process";

function Process() {
  return (
    <section
      id="process"
      className="reveal bg-[#050505] py-32 text-white"
    >
      <div className="mx-auto max-w-7xl px-6">

        <SectionHeading
          subtitle="Our Process"
          title="From Idea To Reality"
          description="Every successful project follows a structured workflow. Here's how NeoStack transforms your ideas into premium digital products."
        />

        <div className="relative mt-24">

          {/* Center Line */}

          <div className="absolute left-1/2 hidden h-full w-[2px] -translate-x-1/2 bg-white/10 lg:block" />

          {process.map((step, index) => (

            <div
              key={step.id}
              className={`relative mb-20 grid items-center gap-12 lg:grid-cols-2 ${
                index % 2 !== 0
                  ? "lg:[&>*:first-child]:order-2"
                  : ""
              }`}
            >

              {/* Content */}

              <div
                className={`${
                  index % 2 === 0
                    ? "lg:pr-16"
                    : "lg:pl-16"
                }`}
              >

                <div className="rounded-[32px] border border-white/10 bg-[#101010] p-10 transition duration-500 hover:-translate-y-2 hover:border-yellow-400">

                  <span className="text-sm uppercase tracking-[6px] text-yellow-400">
                    Step {step.id}
                  </span>

                  <h3 className="mt-5 text-4xl font-bold">
                    {step.title}
                  </h3>

                  <p className="mt-6 leading-8 text-gray-400">
                    {step.description}
                  </p>

                </div>

              </div>

              {/* Timeline */}

              <div className="relative flex justify-center">

                <div className="absolute hidden h-[2px] w-20 bg-white/10 lg:block" />

                <div className="relative z-10 flex h-24 w-24 items-center justify-center rounded-full border border-yellow-400 bg-[#111111] text-3xl font-bold text-yellow-400 shadow-[0_0_35px_rgba(245,183,0,0.18)]">

                  {step.id}

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>
    </section>
  );
}

export default Process;