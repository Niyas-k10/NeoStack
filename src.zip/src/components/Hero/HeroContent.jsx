import Button from "../common/Button";

function HeroContent() {
  return (
    <div className="max-w-4xl text-center">

      <p className="inline-flex rounded-full border border-yellow-500/20 bg-yellow-500/10 px-6 py-2 text-sm uppercase tracking-[6px] text-yellow-400">
        Build • Scale • Evolve
      </p>

      <h1 className="mt-8 text-5xl font-bold leading-tight text-white md:text-7xl">

        Crafting

        <span className="block text-yellow-400">

          Digital Experiences

        </span>

        That Drive Growth

      </h1>

      <p className="mx-auto mt-8 max-w-3xl text-lg leading-8 text-gray-400">

        NeoStack helps startups and businesses build
        premium websites, branding, UI/UX design,
        digital products and creative marketing
        experiences that leave a lasting impression.

      </p>

      <div className="mt-10 flex flex-wrap justify-center gap-5">

        <Button>

          Start Project

        </Button>

        <Button variant="secondary">

          View Portfolio

        </Button>

      </div>

    </div>
  );
}

export default HeroContent;