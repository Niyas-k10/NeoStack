function SectionHeading({
  subtitle,
  title,
  description,
  center = true,
}) {
  return (
    <div className={center ? "text-center" : ""}>
      <p className="uppercase tracking-[6px] text-yellow-400">
        {subtitle}
      </p>

      <h2 className="mt-4 text-4xl font-bold lg:text-5xl">
        {title}
      </h2>

      <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-gray-400">
        {description}
      </p>
    </div>
  );
}

export default SectionHeading;