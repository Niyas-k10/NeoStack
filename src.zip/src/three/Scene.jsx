import CameraRig from "./CameraRig";
import Lights from "./Lights";
import ResponsiveScene from "./ResponsiveScene";
import Effects from "./Effects";

function Scene() {
  return (
    <>
      <Lights />

      <CameraRig>
        <ResponsiveScene />
      </CameraRig>

      <Effects />
    </>
  );
}

export default Scene;