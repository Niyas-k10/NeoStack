import { useState } from "react";
import { HiOutlineMenuAlt3, HiOutlineX } from "react-icons/hi";
import { useGSAP } from "@gsap/react";
import { navbarAnimation } from "../../animations/navbarAnimation";

const navLinks = [
  { name: "Home", href: "#hero" },
  { name: "Services", href: "#services" },
  { name: "Portfolio", href: "#portfolio" },
  { name: "About", href: "#about" },
  { name: "Contact", href: "#contact" },
];

function Navbar() {
  useGSAP(() => {
  navbarAnimation();
}, []);

  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="navbar fixed top-0 left-0 z-50 w-full border-b border-white/10 bg-black/40 backdrop-blur-xl">

      <div className="mx-auto flex h-24 max-w-7xl items-center justify-between px-6 lg:px-8">

        {/* Logo */}

        <a
          href="#hero"
          className="flex items-center gap-4"
        >

          <img
            src="/logo.png"
            alt="NeoStack"
            className="h-25 w-auto sm:h-12 lg:h-28"
          />

        </a>

        {/* Desktop Menu */}

        <nav className="hidden lg:block">

          <ul className="flex items-center gap-10">

            {navLinks.map((link) => (

              <li key={link.name}>

                <a
                  href={link.href}
                  className="relative text-lg font-medium text-gray-300 transition duration-300 hover:text-yellow-400"
                >
                  {link.name}
                </a>

              </li>

            ))}

          </ul>

        </nav>

        {/* Desktop Button */}

        <a
          href="#contact"
          className="hidden rounded-2xl bg-yellow-500 px-7 py-3 font-semibold text-black transition duration-300 hover:scale-105 hover:bg-yellow-400 lg:block"
        >
          Let's Talk
        </a>

        {/* Mobile Menu Button */}

        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="text-3xl text-white lg:hidden"
        >

          {menuOpen ? <HiOutlineX /> : <HiOutlineMenuAlt3 />}

        </button>

      </div>

      {/* Mobile Menu */}

      <div
        className={`overflow-hidden border-t border-white/10 bg-[#0d0d0d] transition-all duration-500 lg:hidden ${
          menuOpen ? "max-h-[500px]" : "max-h-0"
        }`}
      >

        <ul className="flex flex-col px-6 py-6">

          {navLinks.map((link) => (

            <li key={link.name}>

              <a
                href={link.href}
                onClick={() => setMenuOpen(false)}
                className="block border-b border-white/5 py-5 text-lg text-gray-300 transition hover:text-yellow-400"
              >
                {link.name}
              </a>

            </li>

          ))}

          <a
            href="#contact"
            onClick={() => setMenuOpen(false)}
            className="mt-6 rounded-xl bg-yellow-500 py-4 text-center font-semibold text-black transition hover:bg-yellow-400"
          >
            Let's Talk
          </a>

        </ul>

      </div>

    </header>
  );
}

export default Navbar;