import SectionHeading from "../common/SectionHeading";

const technologies = [
  "React",
  "JavaScript",
  "Tailwind CSS",
  "Vite",
  "Python",
  "Django",
  "Django REST Framework",
  "MySQL",
  "Git",
  "GitHub",
  "Three.js",
  "React Three Fiber",
  "GSAP",
  "Framer Motion",
  "Spline",
  "Blender",
];

function TechStack() {
  return (
    <section
      id="tech"
      className="reveal bg-[#050505] py-32 text-white"
    >
      <div className="mx-auto max-w-7xl px-6">

        <SectionHeading
          subtitle="Technology Stack"
          title="Built With Modern Technologies"
          description="We use industry-standard tools and technologies to build fast, scalable and premium digital products."
        />

        <div className="mt-20 grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-4">

          {technologies.map((tech) => (
            <div
              key={tech}
              className="group rounded-2xl border border-white/10 bg-[#111111] p-6 transition-all duration-300 hover:-translate-y-2 hover:border-yellow-400 hover:bg-[#171717]"
            >
              <h3 className="text-center text-lg font-semibold transition duration-300 group-hover:text-yellow-400">
                {tech}
              </h3>
            </div>
          ))}

        </div>

      </div>
    </section>
  );
}

export default TechStack;