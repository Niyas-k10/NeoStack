function Card({ children }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-[#111111] p-8 transition-all duration-300 hover:-translate-y-2 hover:border-yellow-400">
      {children}
    </div>
  );
}

export default Card;