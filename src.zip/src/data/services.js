const services = [
  {
    id: 1,
    title: "Website Development",
    description:
      "Fast, responsive and scalable websites built with React, Django and modern technologies to grow your business online.",
  },
  {
    id: 2,
    title: "Brand Identity",
    description:
      "Professional logos, color systems and branding that make your business memorable.",
  },
  {
    id: 3,
    title: "Digital Marketing",
    description:
      "Creative marketing strategies and social media campaigns that attract more customers.",
  },
  {
    id: 4,
    title: "Poster Design",
    description:
      "Eye-catching promotional posters and digital creatives for businesses.",
  },
  {
    id: 5,
    title: "ATS Resume",
    description:
      "Professional ATS-friendly resumes designed to increase interview opportunities.",
  },
  {
    id: 6,
    title: "Business Consultation",
    description:
      "Helping startups choose the right technologies and digital strategy for growth.",
  },
];

export default services;