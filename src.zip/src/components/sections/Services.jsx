import SectionHeading from "../common/SectionHeading";
import services from "../../data/services";

function Services() {
  return (
    <section
  id="services"
  className="reveal services-section bg-[#050505] py-32 text-white"
>
      <div className="mx-auto max-w-7xl px-6">

        <SectionHeading
          subtitle="Our Services"
          title="Everything You Need To Build A Powerful Brand"
          description="NeoStack combines modern design, development and marketing to help businesses establish a strong digital presence."
        />

        <div className="mt-20 grid gap-6 lg:grid-cols-12">

          {/* Featured Card */}

          <div className="group relative overflow-hidden rounded-[32px] border border-white/10 bg-[#111111] p-10 transition-all duration-500 hover:-translate-y-2 hover:border-yellow-400 lg:col-span-7">

            <div className="absolute -right-24 -top-24 h-60 w-60 rounded-full bg-yellow-500/10 blur-[100px]" />

            <div className="relative">

              <p className="text-sm uppercase tracking-[6px] text-yellow-400">
                Featured Service
              </p>

              <h2 className="mt-6 text-4xl font-bold leading-tight lg:text-5xl">
                {services[0].title}
              </h2>

              <p className="mt-8 max-w-xl leading-8 text-gray-400">
                {services[0].description}
              </p>

              <button className="mt-12 rounded-xl border border-yellow-400 px-6 py-3 text-yellow-400 transition hover:bg-yellow-400 hover:text-black">
                Learn More
              </button>

            </div>

          </div>

          {/* Right Side */}

          <div className="grid gap-6 lg:col-span-5">

            {services.slice(1, 3).map((service) => (

              <div
                key={service.id}
                className="group rounded-[28px] border border-white/10 bg-[#111111] p-8 transition-all duration-500 hover:-translate-y-2 hover:border-yellow-400"
              >

                <h3 className="text-2xl font-bold">
                  {service.title}
                </h3>

                <p className="mt-5 leading-8 text-gray-400">
                  {service.description}
                </p>

              </div>

            ))}

          </div>

        </div>

        {/* Bottom Cards */}

        <div className="mt-6 grid gap-6 md:grid-cols-3">

          {services.slice(3).map((service) => (

            <div
              key={service.id}
              className="group rounded-[28px] border border-white/10 bg-[#111111] p-8 transition-all duration-500 hover:-translate-y-2 hover:border-yellow-400"
            >

              <h3 className="text-2xl font-bold">
                {service.title}
              </h3>

              <p className="mt-5 leading-8 text-gray-400">
                {service.description}
              </p>

            </div>

          ))}

        </div>

      </div>
    </section>
  );
}

export default Services;