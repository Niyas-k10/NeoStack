import SectionHeading from "../common/SectionHeading";

import {
  FaWhatsapp,
  FaInstagram,
  FaPhoneAlt,
} from "react-icons/fa";

import { MdEmail } from "react-icons/md";

const contacts = [
  {
    id: 1,
    title: "WhatsApp",
    description: "Chat with our team instantly.",
    value: "+91 XXXXX XXXXX",
    link: "https://wa.me/91XXXXXXXXXX",
    icon: FaWhatsapp,
  },
  {
    id: 2,
    title: "Instagram",
    description: "See our latest projects and updates.",
    value: "@neostack.in",
    link: "https://instagram.com/neostack.in",
    icon: FaInstagram,
  },
  {
    id: 3,
    title: "Phone",
    description: "Call us to discuss your project.",
    value: "+91 XXXXX XXXXX",
    link: "tel:+91XXXXXXXXXX",
    icon: FaPhoneAlt,
  },
  {
    id: 4,
    title: "Email",
    description: "Send us your project requirements.",
    value: "hello@neostack.in",
    link: "mailto:hello@neostack.in",
    icon: MdEmail,
  },
];

function Contact() {
  return (
    <section
      id="contact"
      className="reveal bg-[#050505] py-32 text-white"
    >
      <div className="mx-auto max-w-7xl px-6">

        <SectionHeading
          subtitle="Let's Connect"
          title="Ready To Build Something Amazing?"
          description="Choose your preferred way to connect with NeoStack."
        />

        <div className="mt-20 grid gap-8 lg:grid-cols-12">

          {/* WhatsApp */}

          <a
            href={contacts[0].link}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative overflow-hidden rounded-[36px] border border-white/10 bg-[#101010] p-10 transition-all duration-500 hover:-translate-y-2 hover:border-yellow-400 hover:shadow-[0_0_50px_rgba(245,183,0,0.12)] lg:col-span-12"
          >
            <div className="absolute -right-20 -top-20 h-60 w-60 rounded-full bg-yellow-500/10 blur-[120px]" />

            <div className="relative flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">

              <div>

                <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-yellow-500 text-4xl text-black">

                  <FaWhatsapp />

                </div>

                <h2 className="mt-8 text-4xl font-bold">
                  WhatsApp
                </h2>

                <p className="mt-4 max-w-xl leading-8 text-gray-400">
                  Chat directly with our team and get a quick response
                  regarding your website, branding or marketing project.
                </p>

              </div>

              <div className="text-left lg:text-right">

                <p className="text-lg text-yellow-400">
                  {contacts[0].value}
                </p>

                <p className="mt-3 text-gray-500">
                  Click to start chatting
                </p>

              </div>

            </div>

          </a>

          {/* Instagram */}

          {contacts.slice(1).map((item) => {
            const Icon = item.icon;

            return (
              <a
                key={item.id}
                href={item.link}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative overflow-hidden rounded-[32px] border border-white/10 bg-[#101010] p-8 transition-all duration-500 hover:-translate-y-2 hover:border-yellow-400 hover:shadow-[0_0_40px_rgba(245,183,0,0.08)] lg:col-span-4"
              >
                <div className="absolute -right-12 -top-12 h-40 w-40 rounded-full bg-yellow-500/10 blur-[80px]" />

                <div className="relative">

                  <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-yellow-500 text-3xl text-black">

                    <Icon />

                  </div>

                  <h3 className="mt-8 text-3xl font-bold transition group-hover:text-yellow-400">
                    {item.title}
                  </h3>

                  <p className="mt-4 leading-8 text-gray-400">
                    {item.description}
                  </p>

                  <p className="mt-8 font-medium text-yellow-400">
                    {item.value}
                  </p>

                </div>

              </a>
            );
          })}

        </div>

      </div>
    </section>
  );
}

export default Contact;