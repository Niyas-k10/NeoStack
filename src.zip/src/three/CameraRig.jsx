import { useFrame, useThree } from "@react-three/fiber";
import { easing } from "maath";
import { useRef } from "react";

function CameraRig({ children }) {
  const group = useRef();

  const { pointer } = useThree();

  useFrame((state, delta) => {
    easing.dampE(
      group.current.rotation,
      [
        pointer.y * 0.12,
        pointer.x * 0.25,
        0,
      ],
      0.25,
      delta
    );
  });

  return (
    <group ref={group}>
      {children}
    </group>
  );
}

export default CameraRig;