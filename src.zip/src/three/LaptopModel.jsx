import { useGLTF } from "@react-three/drei";

function LaptopModel() {
  const { scene } = useGLTF("/models/macbook.glb");

  return (
    <primitive
      object={scene}
      scale={10}
      position={[2, -0.3, 1.9]}
      rotation={[0.12, 0.40, 0]}
    />
  );
}

useGLTF.preload("/models/macbook.glb");

export default LaptopModel;