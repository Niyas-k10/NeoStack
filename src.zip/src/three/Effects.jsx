import { EffectComposer, Bloom } from "@react-three/postprocessing";

function Effects() {
  return (
    <EffectComposer>

      <Bloom
  intensity={0.2}
  luminanceThreshold={0.8}
  mipmapBlur
/>

    </EffectComposer>
  );
}

export default Effects;