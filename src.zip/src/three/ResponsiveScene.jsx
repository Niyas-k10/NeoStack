import { Float } from "@react-three/drei";
import { useThree } from "@react-three/fiber";
import LaptopModel from "./LaptopModel";

function ResponsiveScene() {

  const { viewport } = useThree();

  let scale = 0.7;

  if (viewport.width > 12)
    scale = 1;

  else if (viewport.width > 8)
    scale = 0.82;

  else
    scale = 0.62;

  return (

    <Float

      speed={1.4}

      rotationIntensity={0.12}

      floatIntensity={0.35}

      floatingRange={[-0.08,0.08]}

    >

      <group
        scale={scale}
        position={[0,-0.8,0]}
      >

        <LaptopModel />

      </group>

    </Float>

  );

}

export default ResponsiveScene;