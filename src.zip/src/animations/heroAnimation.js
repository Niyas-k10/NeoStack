import gsap from "gsap";

export function heroAnimation() {
  const tl = gsap.timeline({
    defaults: {
      ease: "power4.out",
    },
  });

  // Initial Reveal
  tl.from(".hero-scene", {
    opacity: 0,
    scale: 0.75,
    y: 80,
    duration: 1.4,
  })

    .from(
      ".hero-badge",
      {
        opacity: 0,
        y: 30,
        duration: 0.6,
      },
      "-=0.9"
    )

    .from(
      ".hero-title span",
      {
        opacity: 0,
        y: 120,
        stagger: 0.12,
        duration: 0.8,
      },
      "-=0.5"
    )

    .from(
      ".hero-description",
      {
        opacity: 0,
        y: 40,
        duration: 0.6,
      },
      "-=0.4"
    )

    .from(
      ".hero-buttons",
      {
        opacity: 0,
        y: 40,
        duration: 0.6,
      },
      "-=0.3"
    )

    .from(
      ".hero-scroll",
      {
        opacity: 0,
        y: 20,
        duration: 0.5,
      },
      "-=0.3"
    );

  // Floating Animation

  gsap.to(".hero-scene", {
    y: -18,
    duration: 2.5,
    repeat: -1,
    yoyo: true,
    ease: "sine.inOut",
  });

  gsap.to(".floating-dot", {
    y: -25,
    repeat: -1,
    stagger: 0.2,
    yoyo: true,
    duration: 2,
    ease: "sine.inOut",
  });

  // Mouse Parallax

  window.addEventListener("mousemove", (e) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 40;
    const y = (e.clientY / window.innerHeight - 0.5) * 40;

    gsap.to(".hero-scene", {
      x,
      y,
      duration: 1,
      ease: "power3.out",
    });
  });
}