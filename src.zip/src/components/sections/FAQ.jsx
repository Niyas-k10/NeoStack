import { useState } from "react";
import SectionHeading from "../common/SectionHeading";
import faq from "../../data/faq";

function FAQ() {
  const [active, setActive] = useState(1);

  const toggleAccordion = (id) => {
    setActive(active === id ? null : id);
  };

  return (
    <section
      id="faq"
      className="reveal bg-[#050505] py-32 text-white"
    >
      <div className="mx-auto max-w-5xl px-6">

        <SectionHeading
          subtitle="Frequently Asked Questions"
          title="Questions We Often Receive"
          description="Everything you need to know before starting your project with NeoStack."
        />

        <div className="mt-20 space-y-6">

          {faq.map((item) => (

            <div
              key={item.id}
              className="overflow-hidden rounded-[28px] border border-white/10 bg-[#101010] transition duration-300 hover:border-yellow-400"
            >

              <button
                onClick={() => toggleAccordion(item.id)}
                className="flex w-full items-center justify-between px-8 py-7 text-left"
              >

                <h3 className="text-xl font-semibold">
                  {item.question}
                </h3>

                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full border transition-all duration-300 ${
                    active === item.id
                      ? "border-yellow-400 bg-yellow-400 text-black"
                      : "border-white/10 text-white"
                  }`}
                >
                  {active === item.id ? "−" : "+"}
                </div>

              </button>

              <div
                className={`grid transition-all duration-500 ${
                  active === item.id
                    ? "grid-rows-[1fr]"
                    : "grid-rows-[0fr]"
                }`}
              >

                <div className="overflow-hidden">

                  <p className="border-t border-white/10 px-8 py-7 leading-8 text-gray-400">
                    {item.answer}
                  </p>

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>
    </section>
  );
}

export default FAQ;