import { Canvas } from "@react-three/fiber";
import Scene from "./Scene";

function HeroCanvas() {
  return (

    <div className="h-[350px] md:h-[500px] lg:h-[650px] w-full">

      <Canvas

        camera={{
  position:[0,1.8,9],
  fov:28
}}

      >

        <Scene />

      </Canvas>

    </div>

  );
}

export default HeroCanvas;