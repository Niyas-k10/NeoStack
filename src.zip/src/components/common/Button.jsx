function Button({
  children,
  variant = "primary",
  type = "button",
}) {
  const base =
    "inline-flex items-center justify-center rounded-2xl px-8 py-4 text-sm font-semibold transition-all duration-500 hover:scale-105 active:scale-95";

  const variants = {
    primary:
      "bg-yellow-500 text-black hover:-translate-y-1 hover:bg-yellow-400 hover:shadow-[0_0_35px_rgba(245,183,0,.35)]",

    secondary:
      "border border-white/10 bg-white/5 text-white backdrop-blur-md hover:-translate-y-1 hover:border-yellow-400 hover:bg-yellow-500/10 hover:text-yellow-400",
  };

  return (
    <button
      type={type}
      className={`${base} ${variants[variant]}`}
    >
      {children}
    </button>
  );
}

export default Button;