import { Environment } from "@react-three/drei";

function Lights() {
  return (
    <>
      <ambientLight intensity={1.1} />

      <directionalLight
        position={[5, 5, 5]}
        intensity={2}
      />

      <directionalLight
        position={[-4, 4, -3]}
        intensity={0.8}
      />

      <pointLight
        position={[0, 3, 4]}
        intensity={1.5}
        color="#facc15"
      />

      <Environment preset="studio" />
    </>
  );
}

export default Lights;