import SectionHeading from "../common/SectionHeading";
import Button from "../common/Button";
import projects from "../../data/projects";

function Portfolio() {
  return (
    <section
      id="portfolio"
      className="reveal bg-[#050505] py-32 text-white"
    >
      <div className="mx-auto max-w-7xl px-6">

        <SectionHeading
          subtitle="Portfolio"
          title="Featured Projects"
          description="A selection of projects crafted with modern technologies, premium design and scalable architecture."
        />

        <div className="mt-20 space-y-10">

          {projects.map((project, index) => (

            <div
              key={project.id}
              className={`grid items-center gap-10 rounded-[36px] border border-white/10 bg-[#101010] p-8 transition duration-500 hover:border-yellow-400 lg:grid-cols-2 ${
                index % 2 !== 0 ? "lg:[&>*:first-child]:order-2" : ""
              }`}
            >

              {/* Image */}

              <div>

                <div className="flex h-[380px] items-center justify-center overflow-hidden rounded-[28px] border border-white/10 bg-[#181818]">

                  <span className="text-xl text-gray-500">
                    {project.title} Preview
                  </span>

                </div>

              </div>

              {/* Content */}

              <div>

                <p className="uppercase tracking-[5px] text-yellow-400">
                  {project.category}
                </p>

                <h2 className="mt-5 text-4xl font-bold lg:text-5xl">
                  {project.title}
                </h2>

                <p className="mt-8 leading-8 text-gray-400">
                  {project.description}
                </p>

                <div className="mt-10 flex flex-wrap gap-3">

                  {project.technologies.map((tech) => (

                    <span
                      key={tech}
                      className="rounded-full border border-white/10 bg-[#181818] px-5 py-2 text-sm"
                    >
                      {tech}
                    </span>

                  ))}

                </div>

                <div className="mt-10">

                  <Button>
                    View Case Study
                  </Button>

                </div>

              </div>

            </div>

          ))}

        </div>

      </div>
    </section>
  );
}

export default Portfolio;