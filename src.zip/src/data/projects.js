const projects = [
  {
    id: 1,
    category: "Business Website",
    title: "NeoStack Agency Website",
    description:
      "A premium digital agency website focused on modern UI, animations and immersive user experience.",
    technologies: [
      "React",
      "Tailwind CSS",
      "GSAP",
      "Three.js",
    ],
    image: "/projects/neostack.webp",
  },
  {
    id: 2,
    category: "Travel Platform",
    title: "Voyago",
    description:
      "A complete travel booking platform with authentication, bookings, destinations and admin dashboard.",
    technologies: [
      "React",
      "Django",
      "REST API",
      "MySQL",
    ],
    image: "/projects/voyago.webp",
  },
  {
    id: 3,
    category: "AI Security",
    title: "PrisonEYE",
    description:
      "AI-powered prison monitoring system with facial recognition, inmate tracking and real-time alerts.",
    technologies: [
      "Python",
      "OpenCV",
      "Django",
      "AI",
    ],
    image: "/projects/prisoneye.webp",
  },
];

export default projects;