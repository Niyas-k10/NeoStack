import Navbar from "./components/layout/Navbar";
import Hero from "./components/Hero/Hero";
import TechStack from "./components/sections/TechStack";import Services from "./components/sections/Services";
import WhyChoose from "./components/sections/WhyChoose";
import Portfolio from "./components/sections/Portfolio";
import Process from "./components/sections/Process";
import FAQ from "./components/sections/FAQ";
import Contact from "./components/sections/Contact";
import Footer from "./components/layout/Footer";
import useLenis from "./hooks/useLenis";
import { useGSAP } from "@gsap/react";
import { scrollAnimation } from "./animations/scrollAnimation";

function App() {
  


  useLenis();
  useGSAP(() => {
  scrollAnimation();
}, []);

  return (
    <div className="bg-[#050505]">
      <Navbar />
      <Hero />
      <Services />
      <TechStack />
      <Portfolio />
      <WhyChoose />
      <Process />
      <FAQ />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;